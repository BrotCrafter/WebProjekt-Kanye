const express = require('express');
const path = require('path');

const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('Anmeldung');
});

//Routen
app.get('/Anmeldung', (req, res) => {
  res.render('Anmeldung');
});

//Zitate für die Startseite und Einbindung davon
app.get('/index', (req, res) => {
  res.locals.pageType = 'index-page';
  const kanyeQuotes = [
    "I am a god. So hurry up with my damn massage. In a French-ass restaurant. Hurry up with my damn croissants.",
    "I'mma let you finish, but Beyoncé had one of the best videos of all time!",
    "My greatest pain in life is that I will never be able to see myself perform live.",
    "I hate when I'm on a flight and I wake up with a water bottle next to me like oh great now I gotta be responsible for this water bottle.",
    "Sometimes people write novels and they just be so wordy and so self-absorbed.",
    "I am Warhol. I am the number one most impactful artist of our generation.",
    "I feel like I'm too busy writing history to read it.",
    "My music isn't just music - it's medicine.",
    "I'm not a fan of books. I would never want a book's autograph.",
    "I am Shakespeare in the flesh.",
    "I'm living in the future so the present is my past.",
    "I refuse to accept other people's ideas of happiness for me.",
    "Believe in your flyness, conquer your shyness.",
    "I'm nice at ping pong.",
    "I make awesome decisions in bike stores.",
    "I still think I am the greatest.",
    "I am one of the most famous people on the planet.",
    "I'm a creative genius and there's no other way to word it.",
    "I'm the best living recording artist.",
    "I am God's vessel.",
    "I'm not even a person. I'm a creative genius.",
    "I'm the nucleus.",
    "I'm a superhero. I'm like a walking superhero.",
    "I'm the closest that hip-hop is getting to God.",
    "I am the Steve Jobs of internet, downtown, fashion, culture.",
    "I'm going down as a legend, whether or not you like me or not.",
    "I'm the most influential person in fashion.",
    "I'm a pop enigma. I live and breathe every element in life.",
    "I'm obsessively opposed to the typical.",
    "I'm the king of the world!"
  ];
  //Zufällige Ausgabe der Zitate
  const randomQuote = kanyeQuotes[Math.floor(Math.random() * kanyeQuotes.length)];
  res.render('index', { name: null, quote: randomQuote });
});

//Routen
app.get('/about', (req, res) => {
  res.render('about');
});

app.get('/albums', (req, res) => {
  res.locals.pageType = 'albums-page';
  res.render('albums');
});

app.get('/biography', (req, res) => {
  res.render('biography');
});

app.get('/grammys', (req, res) => {
  res.render('grammys');
});

app.get('/quiz', (req, res) => {
  res.render('quiz');
});

app.get('/quiz/beginner', (req, res) => {
  res.render('quiz-beginner');
});

app.get('/quiz/intermediate', (req, res) => {
  res.render('quiz-intermediate');
});

app.get('/quiz/expert', (req, res) => {
  res.render('quiz-expert');
});

app.get('/contact', (req, res) => {
  res.render('contact');
});

app.get('/imprint', (req, res) => {
  res.render('imprint');
});

app.get('/privacy', (req, res) => {
  res.render('privacy');
});

//Style der Alben
app.get('/album/:albumId', (req, res) => {
  const albums = {
    'college-dropout': {
      title: 'The College Dropout',
      year: '2004',
      image: '/images/the-college-dropout.jpg',
      color: 'linear-gradient(135deg, #8B4513, #D2691E)',
      songs: ['We Don\'t Care', 'Graduation Day', 'All Falls Down', 'I\'ll Fly Away', 'Spaceship', 'Jesus Walks', 'Never Let Me Down', 'Get Em High', 'Workout Plan', 'The New Workout Plan', 'Slow Jamz', 'Breathe In Breathe Out', 'School Spirit', 'Two Words', 'Through the Wire', 'Family Business', 'Last Call']
    },
    'late-registration': {
      title: 'Late Registration',
      year: '2005',
      image: '/images/late.jpg',
      color: 'linear-gradient(135deg, #b87e67ff, #8a5a02ff)',
      songs: ['Wake Up Mr. West', 'Heard \'Em Say', 'Touch the Sky', 'Gold Digger', 'Skit #1', 'Drive Slow', 'My Way Home', 'Crack Music', 'Roses', 'Bring Me Down', 'Addiction', 'Skit #2', 'Diamonds from Sierra Leone', 'We Major', 'Skit #3', 'Hey Mama', 'Celebration', 'Skit #4', 'Gone', 'Diamonds from Sierra Leone (Bonus Track)', 'Late']
    },
    'graduation': {
      title: 'Graduation',
      year: '2007',
      image: '/images/graduation.jpg',
      color: 'linear-gradient(135deg, #FF69B4, #FF1493)',
      songs: ['Good Morning', 'Champion', 'Stronger', 'I Wonder', 'Good Life', 'Can\'t Tell Me Nothing', 'Barry Bonds', 'Drunk and Hot Girls', 'Flashing Lights', 'Everything I Am', 'The Glory', 'Homecoming', 'Big Brother']
    },
    '808s-heartbreak': {
      title: '808s & Heartbreak',
      year: '2008',
      image: '/images/808s.jpg',
      color: 'linear-gradient(135deg, #d6d6d6ff, #ff5151ff)',
      songs: ['Say You Will', 'Welcome to Heartbreak', 'Heartless', 'Amazing', 'Love Lockdown', 'Paranoid', 'RoboCop', 'Street Lights', 'Bad News', 'See You in My Nightmares', 'Coldest Winter', 'Pinocchio Story']
    },
    'mbdtf': {
      title: 'My Beautiful Dark Twisted Fantasy',
      year: '2010',
      image: '/images/mybeautifuldarktwist.jpg',
      color: 'linear-gradient(135deg, #8B0000, #DC143C)',
      songs: ['Dark Fantasy', 'Gorgeous', 'Power', 'All of the Lights (Interlude)', 'All of the Lights', 'Monster', 'So Appalled', 'Devil in a New Dress', 'Runaway', 'Hell of a Life', 'Blame Game', 'Lost in the World', 'Who Will Survive in America']
    },
    'watch-the-throne': {
      title: 'Watch The Throne',
      year: '2011',
      image: '/images/watch-the-throne.jpg',
      color: 'linear-gradient(135deg, #FFD700, #B8860B)',
      songs: ['No Church in the Wild', 'Lift Off', 'Niggas in Paris', 'Otis', 'Gotta Have It', 'New Day', 'That\'s My Bitch', 'Welcome to the Jungle', 'Who Gon Stop Me', 'Murder to Excellence', 'Made in America', 'Why I Love You']
    },
    'yeezus': {
      title: 'Yeezus',
      year: '2013',
      image: '/images/yeezus.jpg',
      color: 'linear-gradient(135deg, #2F4F4F, #708090)',
      songs: ['On Sight', 'Black Skinhead', 'I Am a God', 'New Slaves', 'Hold My Liquor', 'I\'m In It', 'Blood on the Leaves', 'Guilt Trip', 'Send It Up', 'Bound 2']
    },
    'pablo': {
      title: 'The Life of Pablo',
      year: '2016',
      image: '/images/pablo.jpg',
      color: 'linear-gradient(135deg, #FF4500, #FF6347)',
      songs: ['Ultralight Beam', 'Father Stretch My Hands Pt. 1', 'Pt. 2', 'Famous', 'Feedback', 'Low Lights', 'Highlights', 'Freestyle 4', 'I Love Kanye', 'Waves', 'FML', 'Real Friends', 'Wolves', '30 Hours', 'No More Parties in LA', 'Facts', 'Fade', 'Saint Pablo']
    },
    'ye': {
      title: 'ye',
      year: '2018',
      image: '/images/ye.jpg',
      color: 'linear-gradient(135deg, #228B22, #32CD32)',
      songs: ['I Thought About Killing You', 'Yikes', 'All Mine', 'Wouldn\'t Leave', 'No Mistakes', 'Ghost Town', 'Violent Crimes']
    },
    'kids-see-ghosts': {
      title: 'Kids See Ghosts',
      year: '2018',
      image: '/images/kids-see-ghosts-.jpg',
      color: 'linear-gradient(135deg, #b5e4ffff, #ff8686ff)',
      songs: ['Feel the Love', 'Fire', 'Freeee (Ghost Town Pt. 2)', 'Reborn', 'Kids See Ghosts', 'Cudi Montage', '4th Dimension']
    },
    'jesus-is-king': {
      title: 'Jesus Is King',
      year: '2019',
      image: '/images/jesus.jpg',
      color: 'linear-gradient(135deg, #4682B4, #87CEEB)',
      songs: ['Every Hour', 'Selah', 'Follow God', 'Closed on Sunday', 'On God', 'Everything We Need', 'Water', 'God Is', 'Hands On', 'Use This Gospel', 'Jesus Is Lord']
    },
    'donda': {
      title: 'Donda',
      year: '2021',
      image: '/images/donda.jpg',
      color: 'linear-gradient(135deg, #000000, #333333)',
      songs: ['Donda Chant', 'Jail', 'God Breathed', 'Off The Grid', 'Hurricane', 'Praise God', 'Jonah', 'Ok Ok', 'Junya', 'Believe What I Say', '24', 'Remote Control', 'Moon', 'Heaven and Hell', 'Donda', 'Keep My Spirit Alive', 'Jesus Lord', 'New Again', 'Tell The Vision', 'Lord I Need You', 'Pure Souls', 'Come to Life', 'No Child Left Behind']
    },
    'donda-2': {
      title: 'Donda 2',
      year: '2024',
      image: '/images/donda_2.webp',
      color: 'linear-gradient(135deg, #191970, #4B0082)',
      songs: ['True Love', 'Broken Road', 'Get Lost', 'Too Easy', 'Flowers', 'Security', 'We Did It Kid', 'Pablo', 'Louie Bags', 'Happy', 'Sci Fi', 'Selfish', 'Lord Lift Me Up', 'Keep It Burning', 'First Time in a Long Time', 'Mr Miyagi']
    },
    'vultures-1': {
      title: 'Vultures 1',
      year: '2024',
      image: '/images/vultures.webp',
      color: 'linear-gradient(135deg, #a59d9dff, #3b241cff)',
      songs: ['Stars', 'Keys to My Life', 'Paid', 'Talking', 'Back to Me', 'Hoodrat', 'Do It', 'Paperwork', 'Burn', 'Fuk Sumn', 'Vultures', 'Carnival', 'Beg Forgiveness', 'Good (Don\'t Die)', 'Problematic', 'King']
    },
    'vultures-2': {
      title: 'Vultures 2',
      year: '2024',
      image: '/images/vultures2.png',
      color: 'linear-gradient(135deg, #6d6c6eff, #3c493aff)',
      songs: ['Slide', 'Time Moving Slow', 'Promotion', 'Field Trip', 'Fried', 'Husband', 'Lifestyle', 'Forever Rolling', 'Dead', 'My Soul', 'River', 'Bomb', 'Sky City']
    }
  };
  
  const album = albums[req.params.albumId];
  if (!album) {
    return res.status(404).send('Album nicht gefunden');
  }
  
  res.render('album-detail', { album });
});

//Passwörter die wir manuell speichern
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const users = {
    'niclas.wipplinger@tfs-haslach.at': { name: 'Niclas', password: '123456' },
    'emil.kreuzmair@tfs-haslach.at': { name: 'Emil', password: '123456' },
  };

  const kanyeQuotes = [
    "I am a god. So hurry up with my damn massage. In a French-ass restaurant. Hurry up with my damn croissants.",
    "I'mma let you finish, but Beyoncé had one of the best videos of all time!",
    "My greatest pain in life is that I will never be able to see myself perform live.",
    "I hate when I'm on a flight and I wake up with a water bottle next to me like oh great now I gotta be responsible for this water bottle.",
    "Sometimes people write novels and they just be so wordy and so self-absorbed.",
    "I am Warhol. I am the number one most impactful artist of our generation.",
    "I feel like I'm too busy writing history to read it.",
    "My music isn't just music - it's medicine.",
    "I'm not a fan of books. I would never want a book's autograph.",
    "I am Shakespeare in the flesh.",
    "I'm living in the future so the present is my past.",
    "I refuse to accept other people's ideas of happiness for me.",
    "Believe in your flyness, conquer your shyness.",
    "I'm nice at ping pong.",
    "I make awesome decisions in bike stores.",
    "I still think I am the greatest.",
    "I am one of the most famous people on the planet.",
    "I'm a creative genius and there's no other way to word it.",
    "I'm the best living recording artist.",
    "I am God's vessel.",
    "I'm not even a person. I'm a creative genius.",
    "I'm the nucleus.",
    "I'm a superhero. I'm like a walking superhero.",
    "I'm the closest that hip-hop is getting to God.",
    "I am the Steve Jobs of internet, downtown, fashion, culture.",
    "I'm going down as a legend, whether or not you like me or not.",
    "I'm the most influential person in fashion.",
    "I'm a pop enigma. I live and breathe every element in life.",
    "I'm obsessively opposed to the typical.",
    "I'm the king of the world!"
  ];

  const user = users[email];
  if (user && password === user.password) {
    const randomQuote = kanyeQuotes[Math.floor(Math.random() * kanyeQuotes.length)];
    return res.render('index', { name: user.name, quote: randomQuote });
  }
  res.render('Anmeldung', { error: 'Falsche E‑Mail oder Passwort.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server läuft: http://localhost:${PORT}`));